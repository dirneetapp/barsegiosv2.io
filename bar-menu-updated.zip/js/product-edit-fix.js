// Corrección para la funcionalidad de edición de productos

// Función mejorada para editar producto
function editProduct(category, productId) {
    console.log(`Editando producto: ${productId} en categoría: ${category}`);
    
    // Encontrar producto
    const product = productData[category].find(p => p.id === productId);
    
    if (!product) {
        console.error(`Producto no encontrado: ${productId}`);
        alert('Error: Producto no encontrado');
        return;
    }
    
    // Crear modal para el formulario
    const modal = document.createElement('div');
    modal.className = 'admin-form-modal';
    modal.id = `edit-product-${product.id}`;
    
    modal.innerHTML = `
        <div class="admin-form-content">
            <div class="admin-form-header">
                <h3>Editar Producto</h3>
                <span class="close-form">&times;</span>
            </div>
            <div class="admin-form-body">
                <form id="product-form">
                    <div class="form-group">
                        <label for="product-id">ID:</label>
                        <input type="text" id="product-id" value="${product.id}" readonly>
                    </div>
                    <div class="form-group">
                        <label for="product-name-es">Nombre (Español):</label>
                        <input type="text" id="product-name-es" value="${product.name.es}" required>
                    </div>
                    <div class="form-group">
                        <label for="product-name-en">Nombre (Inglés):</label>
                        <input type="text" id="product-name-en" value="${product.name.en}" required>
                    </div>
                    <div class="form-group">
                        <label for="product-name-fr">Nombre (Francés):</label>
                        <input type="text" id="product-name-fr" value="${product.name.fr}" required>
                    </div>
                    <div class="form-group">
                        <label for="product-desc-es">Descripción (Español):</label>
                        <textarea id="product-desc-es" required>${product.description.es}</textarea>
                    </div>
                    <div class="form-group">
                        <label for="product-desc-en">Descripción (Inglés):</label>
                        <textarea id="product-desc-en" required>${product.description.en}</textarea>
                    </div>
                    <div class="form-group">
                        <label for="product-desc-fr">Descripción (Francés):</label>
                        <textarea id="product-desc-fr" required>${product.description.fr}</textarea>
                    </div>
                    <div class="form-group">
                        <label for="product-price">Precio (€):</label>
                        <input type="number" id="product-price" step="0.01" min="0" value="${product.price}" required>
                    </div>
                    <div class="form-group">
                        <label for="product-image">Imagen (URL):</label>
                        <input type="text" id="product-image" value="${product.image}">
                    </div>
                    <div class="image-preview">
                        <img src="${product.image}" alt="Vista previa">
                    </div>
                    <div class="form-actions">
                        <button type="button" class="cancel-btn">Cancelar</button>
                        <button type="submit" class="save-btn">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Configurar eventos
    const closeBtn = modal.querySelector('.close-form');
    const cancelBtn = modal.querySelector('.cancel-btn');
    const form = modal.querySelector('form');
    const imageInput = modal.querySelector('#product-image');
    const imagePreview = modal.querySelector('.image-preview');
    
    closeBtn.addEventListener('click', () => {
        modal.remove();
    });
    
    cancelBtn.addEventListener('click', () => {
        modal.remove();
    });
    
    // Previsualización de imagen
    imageInput.addEventListener('input', () => {
        const imageUrl = imageInput.value;
        
        if (imageUrl) {
            imagePreview.innerHTML = `<img src="${imageUrl}" alt="Vista previa">`;
        } else {
            imagePreview.innerHTML = '<span class="image-preview-placeholder">Vista previa de la imagen</span>';
        }
    });
    
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Recoger datos del formulario
        const updatedProduct = {
            id: document.getElementById('product-id').value,
            name: {
                es: document.getElementById('product-name-es').value,
                en: document.getElementById('product-name-en').value,
                fr: document.getElementById('product-name-fr').value
            },
            description: {
                es: document.getElementById('product-desc-es').value,
                en: document.getElementById('product-desc-en').value,
                fr: document.getElementById('product-desc-fr').value
            },
            price: parseFloat(document.getElementById('product-price').value),
            image: document.getElementById('product-image').value
        };
        
        console.log('Producto actualizado:', updatedProduct);
        
        // Encontrar y actualizar producto existente
        const index = productData[category].findIndex(p => p.id === updatedProduct.id);
        if (index !== -1) {
            productData[category][index] = updatedProduct;
            console.log(`Producto actualizado en índice ${index}`);
            
            // Actualizar interfaz
            loadProductsForCategory(category);
            
            // Si la categoría actual es la que se está editando, actualizar vista
            if (currentState.currentCategory === category) {
                showCategory(category);
            }
            
            // Mostrar mensaje de éxito
            alert('Producto actualizado correctamente');
        } else {
            console.error('No se encontró el producto para actualizar');
            alert('Error al actualizar el producto');
        }
        
        // Cerrar modal
        modal.remove();
    });
    
    // Mostrar modal
    setTimeout(() => {
        modal.classList.add('active');
    }, 10);
}

// Reemplazar la función original con la versión corregida
if (typeof window.originalEditProduct === 'undefined') {
    window.originalEditProduct = window.editProduct || function(){};
}
window.editProduct = editProduct;
