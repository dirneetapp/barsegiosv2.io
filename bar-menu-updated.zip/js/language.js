// Funcionalidad de selección de idiomas

// Función para inicializar el selector de idiomas
function initLanguageSelector() {
    const langButtons = document.querySelectorAll('.lang-btn');
    
    // Establecer idioma por defecto
    document.body.classList.add('lang-es');
    
    // Marcar el botón del idioma por defecto como activo
    langButtons.forEach(btn => {
        if (btn.getAttribute('data-lang') === 'es') {
            btn.classList.add('active');
        }
        
        // Añadir evento de clic a cada botón
        btn.addEventListener('click', function() {
            const lang = this.getAttribute('data-lang');
            changeLanguage(lang);
            
            // Actualizar botones activos
            langButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

// Función para cambiar el idioma
function changeLanguage(lang) {
    // Eliminar todas las clases de idioma del body
    document.body.classList.remove('lang-es', 'lang-en', 'lang-fr');
    
    // Añadir la clase del idioma seleccionado
    document.body.classList.add(`lang-${lang}`);
    
    // Actualizar el estado actual
    if (typeof currentState !== 'undefined') {
        currentState.language = lang;
        
        // Actualizar productos si hay una categoría seleccionada
        if (currentState.currentCategory) {
            showCategory(currentState.currentCategory);
        }
    }
    
    // Guardar preferencia en localStorage
    localStorage.setItem('preferredLanguage', lang);
    
    console.log(`Idioma cambiado a: ${lang}`);
}

// Función para cargar el idioma preferido del usuario
function loadPreferredLanguage() {
    const preferredLanguage = localStorage.getItem('preferredLanguage');
    
    if (preferredLanguage) {
        changeLanguage(preferredLanguage);
        
        // Actualizar botón activo
        const langButtons = document.querySelectorAll('.lang-btn');
        langButtons.forEach(btn => {
            btn.classList.remove('active');
            if (btn.getAttribute('data-lang') === preferredLanguage) {
                btn.classList.add('active');
            }
        });
    }
}

// Inicializar cuando el DOM esté cargado
document.addEventListener('DOMContentLoaded', function() {
    initLanguageSelector();
    loadPreferredLanguage();
});
