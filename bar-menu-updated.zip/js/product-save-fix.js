// Corrección para la funcionalidad de guardar productos y campos opcionales

// Función mejorada para guardar producto
function saveProduct(category, productId = null) {
    console.log(`Guardando producto${productId ? ' con ID: ' + productId : ' nuevo'} en categoría: ${category}`);
    
    // Recoger datos del formulario
    const productNameEs = document.getElementById('product-name-es').value.trim();
    const productNameEn = document.getElementById('product-name-en').value.trim();
    const productNameFr = document.getElementById('product-name-fr').value.trim();
    const productDescEs = document.getElementById('product-desc-es').value.trim();
    const productDescEn = document.getElementById('product-desc-en').value.trim();
    const productDescFr = document.getElementById('product-desc-fr').value.trim();
    const productPrice = document.getElementById('product-price').value;
    const productImage = document.getElementById('product-image').value.trim();
    
    // Validar campos obligatorios
    if (!productNameEs || !productNameEn || !productNameFr || !productPrice) {
        alert('Por favor, complete todos los campos de nombre y precio');
        return false;
    }
    
    // Crear objeto de producto
    const product = {
        id: productId || `${category.substring(0, 3)}${Date.now()}`,
        name: {
            es: productNameEs,
            en: productNameEn,
            fr: productNameFr
        },
        description: {
            es: productDescEs || '',  // Permitir descripción vacía
            en: productDescEn || '',  // Permitir descripción vacía
            fr: productDescFr || ''   // Permitir descripción vacía
        },
        price: parseFloat(productPrice),
        image: productImage || 'assets/images/default-product.jpg'
    };
    
    console.log('Datos del producto a guardar:', product);
    
    // Guardar producto
    if (productId) {
        // Actualizar producto existente
        const index = productData[category].findIndex(p => p.id === productId);
        if (index !== -1) {
            productData[category][index] = product;
            console.log(`Producto actualizado en índice ${index}`);
        } else {
            console.error('No se encontró el producto para actualizar');
            alert('Error al actualizar el producto');
            return false;
        }
    } else {
        // Añadir nuevo producto
        productData[category].push(product);
        console.log('Nuevo producto añadido');
    }
    
    // Actualizar interfaz
    loadProductsForCategory(category);
    
    // Si la categoría actual es la que se está editando, actualizar vista
    if (currentState && currentState.currentCategory === category) {
        showCategory(category);
    }
    
    // Cerrar modal
    const modal = document.querySelector('.admin-form-modal.active');
    if (modal) {
        modal.remove();
    }
    
    // Mostrar mensaje de éxito
    alert(productId ? 'Producto actualizado correctamente' : 'Producto añadido correctamente');
    
    return true;
}

// Función mejorada para añadir producto
function addProduct(category) {
    console.log(`Añadiendo nuevo producto en categoría: ${category}`);
    
    // Crear modal para el formulario
    const modal = document.createElement('div');
    modal.className = 'admin-form-modal';
    modal.id = 'add-product-modal';
    
    modal.innerHTML = `
        <div class="admin-form-content">
            <div class="admin-form-header">
                <h3>Añadir Producto</h3>
                <span class="close-form">&times;</span>
            </div>
            <div class="admin-form-body">
                <form id="product-form">
                    <div class="form-group">
                        <label for="product-name-es">Nombre (Español):</label>
                        <input type="text" id="product-name-es" required>
                    </div>
                    <div class="form-group">
                        <label for="product-name-en">Nombre (Inglés):</label>
                        <input type="text" id="product-name-en" required>
                    </div>
                    <div class="form-group">
                        <label for="product-name-fr">Nombre (Francés):</label>
                        <input type="text" id="product-name-fr" required>
                    </div>
                    <div class="form-group">
                        <label for="product-desc-es">Descripción (Español):</label>
                        <textarea id="product-desc-es"></textarea>
                        <small>Opcional</small>
                    </div>
                    <div class="form-group">
                        <label for="product-desc-en">Descripción (Inglés):</label>
                        <textarea id="product-desc-en"></textarea>
                        <small>Opcional</small>
                    </div>
                    <div class="form-group">
                        <label for="product-desc-fr">Descripción (Francés):</label>
                        <textarea id="product-desc-fr"></textarea>
                        <small>Opcional</small>
                    </div>
                    <div class="form-group">
                        <label for="product-price">Precio (€):</label>
                        <input type="number" id="product-price" step="0.01" min="0" required>
                    </div>
                    <div class="form-group">
                        <label for="product-image">Imagen (URL):</label>
                        <input type="text" id="product-image">
                        <small>Opcional</small>
                    </div>
                    <div class="image-preview">
                        <span class="image-preview-placeholder">Vista previa de la imagen</span>
                    </div>
                    <div class="form-actions">
                        <button type="button" class="cancel-btn">Cancelar</button>
                        <button type="submit" class="save-btn">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Configurar eventos
    const closeBtn = modal.querySelector('.close-form');
    const cancelBtn = modal.querySelector('.cancel-btn');
    const form = modal.querySelector('form');
    const imageInput = modal.querySelector('#product-image');
    const imagePreview = modal.querySelector('.image-preview');
    
    closeBtn.addEventListener('click', () => {
        modal.remove();
    });
    
    cancelBtn.addEventListener('click', () => {
        modal.remove();
    });
    
    // Previsualización de imagen
    imageInput.addEventListener('input', () => {
        const imageUrl = imageInput.value;
        
        if (imageUrl) {
            imagePreview.innerHTML = `<img src="${imageUrl}" alt="Vista previa">`;
        } else {
            imagePreview.innerHTML = '<span class="image-preview-placeholder">Vista previa de la imagen</span>';
        }
    });
    
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        saveProduct(category);
    });
    
    // Mostrar modal
    setTimeout(() => {
        modal.classList.add('active');
    }, 10);
}

// Función mejorada para editar producto
function editProduct(category, productId) {
    console.log(`Editando producto: ${productId} en categoría: ${category}`);
    
    // Encontrar producto
    const product = productData[category].find(p => p.id === productId);
    
    if (!product) {
        console.error(`Producto no encontrado: ${productId}`);
        alert('Error: Producto no encontrado');
        return;
    }
    
    // Crear modal para el formulario
    const modal = document.createElement('div');
    modal.className = 'admin-form-modal';
    modal.id = `edit-product-${product.id}`;
    
    modal.innerHTML = `
        <div class="admin-form-content">
            <div class="admin-form-header">
                <h3>Editar Producto</h3>
                <span class="close-form">&times;</span>
            </div>
            <div class="admin-form-body">
                <form id="product-form">
                    <div class="form-group">
                        <label for="product-id">ID:</label>
                        <input type="text" id="product-id" value="${product.id}" readonly>
                    </div>
                    <div class="form-group">
                        <label for="product-name-es">Nombre (Español):</label>
                        <input type="text" id="product-name-es" value="${product.name.es}" required>
                    </div>
                    <div class="form-group">
                        <label for="product-name-en">Nombre (Inglés):</label>
                        <input type="text" id="product-name-en" value="${product.name.en}" required>
                    </div>
                    <div class="form-group">
                        <label for="product-name-fr">Nombre (Francés):</label>
                        <input type="text" id="product-name-fr" value="${product.name.fr}" required>
                    </div>
                    <div class="form-group">
                        <label for="product-desc-es">Descripción (Español):</label>
                        <textarea id="product-desc-es">${product.description.es || ''}</textarea>
                        <small>Opcional</small>
                    </div>
                    <div class="form-group">
                        <label for="product-desc-en">Descripción (Inglés):</label>
                        <textarea id="product-desc-en">${product.description.en || ''}</textarea>
                        <small>Opcional</small>
                    </div>
                    <div class="form-group">
                        <label for="product-desc-fr">Descripción (Francés):</label>
                        <textarea id="product-desc-fr">${product.description.fr || ''}</textarea>
                        <small>Opcional</small>
                    </div>
                    <div class="form-group">
                        <label for="product-price">Precio (€):</label>
                        <input type="number" id="product-price" step="0.01" min="0" value="${product.price}" required>
                    </div>
                    <div class="form-group">
                        <label for="product-image">Imagen (URL):</label>
                        <input type="text" id="product-image" value="${product.image || ''}">
                        <small>Opcional</small>
                    </div>
                    <div class="image-preview">
                        ${product.image ? `<img src="${product.image}" alt="Vista previa">` : '<span class="image-preview-placeholder">Vista previa de la imagen</span>'}
                    </div>
                    <div class="form-actions">
                        <button type="button" class="cancel-btn">Cancelar</button>
                        <button type="submit" class="save-btn">Guardar</button>
                    </div>
                </form>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Configurar eventos
    const closeBtn = modal.querySelector('.close-form');
    const cancelBtn = modal.querySelector('.cancel-btn');
    const form = modal.querySelector('form');
    const imageInput = modal.querySelector('#product-image');
    const imagePreview = modal.querySelector('.image-preview');
    
    closeBtn.addEventListener('click', () => {
        modal.remove();
    });
    
    cancelBtn.addEventListener('click', () => {
        modal.remove();
    });
    
    // Previsualización de imagen
    imageInput.addEventListener('input', () => {
        const imageUrl = imageInput.value;
        
        if (imageUrl) {
            imagePreview.innerHTML = `<img src="${imageUrl}" alt="Vista previa">`;
        } else {
            imagePreview.innerHTML = '<span class="image-preview-placeholder">Vista previa de la imagen</span>';
        }
    });
    
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        saveProduct(category, product.id);
    });
    
    // Mostrar modal
    setTimeout(() => {
        modal.classList.add('active');
    }, 10);
}

// Reemplazar las funciones originales con las versiones corregidas
if (typeof window.originalSaveProduct === 'undefined') {
    window.originalSaveProduct = window.saveProduct || function(){};
}
window.saveProduct = saveProduct;

if (typeof window.originalAddProduct === 'undefined') {
    window.originalAddProduct = window.addProduct || function(){};
}
window.addProduct = addProduct;

if (typeof window.originalEditProduct === 'undefined') {
    window.originalEditProduct = window.editProduct || function(){};
}
window.editProduct = editProduct;
